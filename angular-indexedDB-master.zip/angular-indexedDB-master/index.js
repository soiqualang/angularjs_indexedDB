require('./angular-indexed-db.js');
module.exports = 'indexedDB';
